package lesson1;

public interface Obstacle {
}

