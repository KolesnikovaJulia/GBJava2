package lesson1;

public class Treadmill implements Obstacle {

    public static final int LENGTH = 100;
    public static final String TITLE = "Беговая дорожка";
}
