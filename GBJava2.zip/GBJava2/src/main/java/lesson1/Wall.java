package lesson1;

public class Wall implements Obstacle{

   public static final int HEIGHT = 3;
   public static final String TITLE= "Стена";
}
