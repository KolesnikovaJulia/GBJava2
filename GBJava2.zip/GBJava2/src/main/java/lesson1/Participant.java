package lesson1;

public interface Participant {

    String name();

    void run ();

    void jump ();

}
